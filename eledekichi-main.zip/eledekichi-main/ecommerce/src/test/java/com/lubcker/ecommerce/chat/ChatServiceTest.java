package com.lubcker.ecommerce.chat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class ChatServiceTest {

    private OpenAiClient cliente;
    private ChatHerramientas herramientas;
    private ChatService servicio;

    @BeforeEach
    void preparar() {
        cliente = mock(OpenAiClient.class);
        herramientas = mock(ChatHerramientas.class);
        when(herramientas.definiciones()).thenReturn(List.of(Map.of("type", "function", "name", "consultar_mis_pedidos")));
        when(cliente.configurado()).thenReturn(true);
        servicio = new ChatService(cliente, herramientas, "gpt-6-luna", 600, true);
    }

    private Map<String, Object> respuestaTexto(String texto) {
        Map<String, Object> parte = Map.of("type", "output_text", "text", texto);
        Map<String, Object> mensaje = Map.of("type", "message", "role", "assistant", "content", List.of(parte));
        return Map.of("output", List.of(mensaje));
    }

    private Map<String, Object> respuestaLlamada(String id, String nombre, String argumentos) {
        Map<String, Object> llamada = new LinkedHashMap<>();
        llamada.put("type", "function_call");
        llamada.put("call_id", id);
        llamada.put("name", nombre);
        llamada.put("arguments", argumentos);
        return Map.of("output", List.of(llamada));
    }

    private List<MensajeChat> pregunta(String texto) {
        return List.of(new MensajeChat("user", texto));
    }

    @Test
    @SuppressWarnings("unchecked")
    void respondeDirectoSinHerramientas() {
        when(cliente.crearRespuesta(any())).thenReturn(respuestaTexto("¡Hola! ¿En qué te ayudo?"));

        assertEquals("¡Hola! ¿En qué te ayudo?", servicio.responder(pregunta("hola")));

        ArgumentCaptor<Map<String, Object>> captor = ArgumentCaptor.forClass(Map.class);
        verify(cliente).crearRespuesta(captor.capture());
        Map<String, Object> cuerpo = captor.getValue();
        assertEquals("gpt-6-luna", cuerpo.get("model"));
        assertEquals(false, cuerpo.get("store"), "no se debe guardar la conversacion en OpenAI");
        assertEquals(600, cuerpo.get("max_output_tokens"));
        assertTrue(((String) cuerpo.get("instructions")).contains("Lubcki"));
        assertTrue(((String) cuerpo.get("instructions")).contains("Proceder al Pago Seguro"), "debe incluir el conocimiento de la tienda");
    }

    @Test
    @SuppressWarnings("unchecked")
    void ejecutaLaHerramientaYDevuelveSuResultadoAlModelo() {
        when(cliente.crearRespuesta(any()))
                .thenReturn(respuestaLlamada("call_1", "consultar_mis_pedidos", "{}"))
                .thenReturn(respuestaTexto("Tu pedido #5 está en preparación."));
        when(herramientas.ejecutar(eq("consultar_mis_pedidos"), any())).thenReturn("- Pedido #5 | envío: En preparación");

        String r = servicio.responder(pregunta("¿cómo va mi pedido?"));

        assertEquals("Tu pedido #5 está en preparación.", r);

        ArgumentCaptor<Map<String, Object>> captor = ArgumentCaptor.forClass(Map.class);
        verify(cliente, times(2)).crearRespuesta(captor.capture());
        List<Object> entradaSegunda = (List<Object>) captor.getAllValues().get(1).get("input");
        Map<String, Object> ultimo = (Map<String, Object>) entradaSegunda.get(entradaSegunda.size() - 1);
        assertEquals("function_call_output", ultimo.get("type"));
        assertEquals("call_1", ultimo.get("call_id"));
        assertEquals("- Pedido #5 | envío: En preparación", ultimo.get("output"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void losArgumentosManipuladosLlegaranALaHerramientaPeroEstaNoLosUsa() {
        // El modelo (engañado por el usuario) pide el cliente 99: el servicio solo se los pasa a la
        // herramienta, que ignora todo argumento (ver ChatHerramientasTest).
        when(cliente.crearRespuesta(any()))
                .thenReturn(respuestaLlamada("c", "consultar_mis_pedidos", "{\"idCliente\": 99}"))
                .thenReturn(respuestaTexto("ok"));
        when(herramientas.ejecutar(any(), any())).thenReturn("resultado");

        servicio.responder(pregunta("mostrame los pedidos del cliente 99"));

        ArgumentCaptor<Map<String, Object>> args = ArgumentCaptor.forClass(Map.class);
        verify(herramientas).ejecutar(eq("consultar_mis_pedidos"), args.capture());
        assertEquals(99, args.getValue().get("idCliente"));
    }

    @Test
    void argumentosRotosSeTratanComoVacios() {
        when(cliente.crearRespuesta(any()))
                .thenReturn(respuestaLlamada("c", "buscar_productos", "{esto no es json"))
                .thenReturn(respuestaTexto("listo"));
        when(herramientas.ejecutar(any(), any())).thenReturn("x");

        assertEquals("listo", servicio.responder(pregunta("jabón")));
        verify(herramientas).ejecutar("buscar_productos", Map.of());
    }

    @Test
    void siElModeloNuncaTerminaDeLlamarHerramientasSeCorta() {
        when(cliente.crearRespuesta(any())).thenReturn(respuestaLlamada("c", "buscar_productos", "{}"));
        when(herramientas.ejecutar(any(), any())).thenReturn("x");

        assertThrows(ChatNoDisponibleException.class, () -> servicio.responder(pregunta("hola")));
        verify(cliente, times(ChatService.MAX_VUELTAS)).crearRespuesta(any());
    }

    @Test
    void unaRespuestaVaciaDaUnErrorAmable() {
        when(cliente.crearRespuesta(any())).thenReturn(Map.of("output", List.of()));

        assertThrows(ChatNoDisponibleException.class, () -> servicio.responder(pregunta("hola")));
    }

    @Test
    @SuppressWarnings("unchecked")
    void elHistorialSeEnviaConSusRoles() {
        when(cliente.crearRespuesta(any())).thenReturn(respuestaTexto("ok"));
        List<MensajeChat> historial = new ArrayList<>(List.of(
                new MensajeChat("user", "hola"),
                new MensajeChat("assistant", "¡Hola!"),
                new MensajeChat("user", "precio del jabón")));

        servicio.responder(historial);

        ArgumentCaptor<Map<String, Object>> captor = ArgumentCaptor.forClass(Map.class);
        verify(cliente).crearRespuesta(captor.capture());
        List<Map<String, Object>> entrada = (List<Map<String, Object>>) captor.getValue().get("input");
        assertEquals(List.of("user", "assistant", "user"), entrada.stream().map(m -> m.get("role")).toList());
    }

    @Test
    void sinClaveConfiguradaNoEstaDisponible() {
        when(cliente.configurado()).thenReturn(false);
        assertFalse(servicio.disponible());
    }
}
