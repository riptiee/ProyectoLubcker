package com.lubcker.ecommerce.repository;

import com.lubcker.ecommerce.model.Detalle_Orden;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Detalle_OrdenRepository extends JpaRepository<Detalle_Orden, Integer> {

    List<Detalle_Orden> findByOrdenIdOrden(int idOrden);

    boolean existsByProductoIdProducto(int idProducto);

    // ¿El cliente compro este producto? No cuentan los pedidos con envio cancelado.
    @Query("select count(d) > 0 from Detalle_Orden d "
            + "where d.orden.cliente.idCliente = :idCliente and d.producto.idProducto = :idProducto "
            + "and not exists (select e from Envio e where e.orden = d.orden and lower(e.estado) = 'cancelado')")
    boolean clienteComproProducto(@Param("idCliente") int idCliente, @Param("idProducto") int idProducto);

    // Total comprado por un cliente (sin pedidos cancelados)
    @Query("select coalesce(sum(d.subtotal), 0) from Detalle_Orden d where d.orden.cliente.idCliente = :idCliente "
            + "and not exists (select e from Envio e where e.orden = d.orden and lower(e.estado) = 'cancelado')")
    long totalGastado(@Param("idCliente") int idCliente);
}
