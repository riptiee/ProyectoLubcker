package com.lubcker.ecommerce.repository;

import com.lubcker.ecommerce.model.Orden;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrdenRepository extends JpaRepository<Orden, Integer> {

    long countByClienteIdCliente(int idCliente);

    // Pedidos de UN cliente, el mas nuevo primero (lo usa el asistente de chat)
    List<Orden> findByClienteIdClienteOrderByIdOrdenDesc(int idCliente);
}
