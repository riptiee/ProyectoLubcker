package com.lubcker.ecommerce.chat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;

import java.net.http.HttpClient;
import java.time.Duration;
import java.util.Map;

// Llamada HTTP a la Responses API de OpenAI (POST {base-url}/responses).
// La clave se lee de la configuracion (nunca se escribe en el codigo) y no se loguea.
@Component
public class OpenAiClient {

    private static final Logger log = LoggerFactory.getLogger(OpenAiClient.class);

    private final String apiKey;
    private final RestClient http;

    public OpenAiClient(@Value("${app.chat.api-key:}") String apiKey,
                        @Value("${app.chat.base-url:https://api.openai.com/v1}") String baseUrl) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();

        HttpClient cliente = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
        JdkClientHttpRequestFactory fabrica = new JdkClientHttpRequestFactory(cliente);
        fabrica.setReadTimeout(Duration.ofSeconds(45));

        this.http = RestClient.builder().baseUrl(baseUrl).requestFactory(fabrica).build();
    }

    public boolean configurado() {
        return !apiKey.isEmpty();
    }

    public Map<String, Object> crearRespuesta(Map<String, Object> cuerpo) {
        if (!configurado()) {
            throw new ChatNoDisponibleException("El asistente todavía no está configurado. Probá más tarde.");
        }
        try {
            return http.post()
                    .uri("/responses")
                    .header("Authorization", "Bearer " + apiKey)
                    .body(cuerpo)
                    .retrieve()
                    .body(new ParameterizedTypeReference<Map<String, Object>>() {});
        } catch (RestClientResponseException e) {
            // Solo el codigo: el cuerpo del error puede incluir fragmentos de la peticion
            log.error("OpenAI respondio con error HTTP {}", e.getStatusCode().value());
            if (e.getStatusCode().value() == 401) {
                throw new ChatNoDisponibleException("El asistente no está disponible por un problema de configuración.");
            }
            if (e.getStatusCode().value() == 429) {
                throw new ChatNoDisponibleException("El asistente está con mucha demanda. Probá de nuevo en un momento.");
            }
            throw new ChatNoDisponibleException("El asistente no pudo responder. Probá de nuevo en un momento.");
        } catch (RestClientException e) {
            log.error("No se pudo conectar con OpenAI: {}", e.getClass().getSimpleName());
            throw new ChatNoDisponibleException("No pude conectarme con el asistente. Probá de nuevo en un momento.");
        }
    }
}
