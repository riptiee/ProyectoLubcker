package com.lubcker.ecommerce.repository;

import com.lubcker.ecommerce.model.Pago;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PagoRepository extends JpaRepository<Pago, Integer> {
    // ¡Listo! No necesitas escribir nada más aquí.
    // Spring ya te da métodos como: save(), findById(), findAll(), deleteById(), etc.

    List<Pago> findByOrdenClienteIdCliente(int idCliente);

    List<Pago> findByOrdenIdOrden(int idOrden);
}
