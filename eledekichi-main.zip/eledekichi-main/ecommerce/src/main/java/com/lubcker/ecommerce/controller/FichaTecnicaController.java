package com.lubcker.ecommerce.controller;

import com.lubcker.ecommerce.dto.FichaTecnicaDTO;
import com.lubcker.ecommerce.dto.FichaTecnicaRequestDTO;
import com.lubcker.ecommerce.model.Ficha_Tecnica;
import com.lubcker.ecommerce.model.Producto;
import com.lubcker.ecommerce.repository.Ficha_TecnicaRepository;
import com.lubcker.ecommerce.repository.ProductoRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/fichas-tecnicas")
public class FichaTecnicaController {

    @Autowired
    private Ficha_TecnicaRepository fichaTecnicaRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @GetMapping
    public List<FichaTecnicaDTO> listar() {
        return fichaTecnicaRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FichaTecnicaDTO> obtener(@PathVariable int id) {
        return fichaTecnicaRepository.findById(id)
                .map(f -> ResponseEntity.ok(toDTO(f)))
                .orElse(ResponseEntity.notFound().build());
    }

    // GET /api/fichas-tecnicas/producto/{idProducto} -> ficha tecnica de un producto puntual
    @GetMapping("/producto/{idProducto}")
    public ResponseEntity<FichaTecnicaDTO> obtenerPorProducto(@PathVariable int idProducto) {
        return fichaTecnicaRepository.findByProductoIdProducto(idProducto)
                .map(f -> ResponseEntity.ok(toDTO(f)))
                .orElse(ResponseEntity.notFound().build());
    }

    // PUT /api/fichas-tecnicas/producto/{idProducto} -> crea la ficha si no existe o la actualiza.
    // Es lo que usa el panel de admin al guardar un producto.
    @PutMapping("/producto/{idProducto}")
    public ResponseEntity<FichaTecnicaDTO> guardarPorProducto(@PathVariable int idProducto,
                                                              @Valid @RequestBody FichaTecnicaRequestDTO datos) {
        Producto producto = productoRepository.findById(idProducto).orElse(null);
        if (producto == null) return ResponseEntity.notFound().build();

        Ficha_Tecnica ficha = fichaTecnicaRepository.findByProductoIdProducto(idProducto).orElseGet(() -> {
            Ficha_Tecnica nueva = new Ficha_Tecnica();
            nueva.setProducto(producto);
            return nueva;
        });
        ficha.setModelo(vacioANull(datos.getModelo()));
        ficha.setPresentacion(vacioANull(datos.getPresentacion()));
        ficha.setDescripcion(vacioANull(datos.getDescripcion()));
        return ResponseEntity.ok(toDTO(fichaTecnicaRepository.save(ficha)));
    }

    @PostMapping
    public ResponseEntity<FichaTecnicaDTO> crear(@Valid @RequestBody FichaTecnicaRequestDTO datos) {
        Producto producto = productoRepository.findById(datos.getIdProducto())
                .orElseThrow(() -> new RuntimeException("Producto no encontrado: " + datos.getIdProducto()));

        Ficha_Tecnica ficha = new Ficha_Tecnica();
        ficha.setProducto(producto);
        ficha.setModelo(datos.getModelo());
        ficha.setPresentacion(datos.getPresentacion());
        ficha.setDescripcion(datos.getDescripcion());

        Ficha_Tecnica guardada = fichaTecnicaRepository.save(ficha);
        return ResponseEntity.status(HttpStatus.CREATED).body(toDTO(guardada));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FichaTecnicaDTO> actualizar(@PathVariable int id, @Valid @RequestBody FichaTecnicaRequestDTO datos) {
        return fichaTecnicaRepository.findById(id)
                .map(ficha -> {
                    ficha.setModelo(datos.getModelo());
                    ficha.setPresentacion(datos.getPresentacion());
                    ficha.setDescripcion(datos.getDescripcion());
                    return ResponseEntity.ok(toDTO(fichaTecnicaRepository.save(ficha)));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable int id) {
        return fichaTecnicaRepository.findById(id)
                .map(ficha -> {
                    Producto producto = ficha.getProducto();
                    if (producto != null) {
                        producto.setFichaTecnica(null);
                        productoRepository.save(producto);
                    }
                    fichaTecnicaRepository.delete(ficha);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    private String vacioANull(String texto) {
        return texto == null || texto.isBlank() ? null : texto.trim();
    }

    private FichaTecnicaDTO toDTO(Ficha_Tecnica f) {
        return new FichaTecnicaDTO(
                f.getIdFicha(),
                f.getProducto() != null ? f.getProducto().getIdProducto() : 0,
                f.getModelo(),
                f.getPresentacion(),
                f.getDescripcion()
        );
    }
}