import React, { useState, useEffect } from 'react';
import { ESTADOS_ENVIO, claseEstadoEnvio, claseEstadoPago, textoEstadoPago } from '../estados';
import { useAviso } from '../useAviso';
import { formatearPrecio } from '../formato';
import './PedidosAdmin.css';
import { etiquetaMedida } from '../medidas';

const API_URL = 'http://localhost:8080/api';

export default function PedidosAdmin() {
  const [ordenes, setOrdenes] = useState([]);
  const [pagos, setPagos] = useState({});   // idOrden -> pago
  const [envios, setEnvios] = useState({}); // idOrden -> envío
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);
  const [busqueda, setBusqueda] = useState('');
  const [aviso, mostrarAviso] = useAviso();

  useEffect(() => {
    const pedir = (ruta) =>
      fetch(`${API_URL}/${ruta}`).then((res) => {
        if (!res.ok) throw new Error('error');
        return res.json();
      });

    Promise.all([pedir('ordenes'), pedir('pagos'), pedir('envios')])
      .then(([listaOrdenes, listaPagos, listaEnvios]) => {
        setOrdenes([...listaOrdenes].sort((a, b) => b.idOrden - a.idOrden));
        setPagos(Object.fromEntries(listaPagos.map((p) => [p.idOrden, p])));
        setEnvios(Object.fromEntries(listaEnvios.map((e) => [e.idOrden, e])));
        setCargando(false);
      })
      .catch(() => {
        setError('No se pudieron cargar los pedidos. ¿Está corriendo el backend?');
        setCargando(false);
      });
  }, []);

  const confirmarPago = (pago) => {
    fetch(`${API_URL}/pagos/${pago.idPago}/confirmar`, { method: 'PUT' })
      .then((res) => {
        if (!res.ok) throw new Error();
        return res.json();
      })
      .then((actualizado) => {
        setPagos((prev) => ({ ...prev, [actualizado.idOrden]: actualizado }));
        mostrarAviso(`Pago del pedido #${actualizado.idOrden} confirmado`);
      })
      .catch(() => mostrarAviso('No se pudo confirmar el pago.', 'error'));
  };

  const cambiarEstadoEnvio = (envio, estado) => {
    if (estado === 'Cancelado' &&
        !window.confirm(`¿Cancelar el pedido #${envio.idOrden}? Las unidades vuelven al stock y el pedido no se podrá reactivar.`)) {
      return;
    }
    // El backend recibe el estado como texto plano (no JSON)
    fetch(`${API_URL}/envios/${envio.idEnvio}/estado`, {
      method: 'PUT',
      headers: { 'Content-Type': 'text/plain' },
      body: estado,
    })
      .then(async (res) => {
        const data = await res.json().catch(() => null);
        if (!res.ok) throw new Error(data?.mensaje || 'No se pudo cambiar el estado del envío.');
        return data;
      })
      .then((actualizado) => {
        setEnvios((prev) => ({ ...prev, [actualizado.idOrden]: actualizado }));
        mostrarAviso(`Envío del pedido #${actualizado.idOrden}: ${actualizado.estado}`);
      })
      .catch((err) => mostrarAviso(err.message, 'error'));
  };

  const total = (orden) => (orden.detalles || []).reduce((suma, d) => suma + d.subtotal, 0);

  const filtradas = ordenes.filter((o) => {
    const texto = busqueda.toLowerCase();
    return (
      String(o.idOrden).includes(texto) ||
      (o.nombreCliente || '').toLowerCase().includes(texto) ||
      (o.detalles || []).some((d) => d.nombreProducto.toLowerCase().includes(texto))
    );
  });

  if (cargando) return <p className="pedidos-vacio">Cargando pedidos...</p>;
  if (error) return <p className="pedidos-vacio">{error}</p>;

  return (
    <div className="pedidos-contenedor">
      {aviso}
      <div className="pedidos-tarjeta">
        <h1 className="pedidos-titulo">Gestión de Pedidos</h1>
        <p className="pedidos-subtitulo">Confirmá los pagos y actualizá el estado de los envíos.</p>

        <div className="pedidos-barra">
          <input
            type="text"
            placeholder="Buscar por pedido, cliente o producto..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="pedidos-busqueda"
          />
          <span className="pedidos-contador">
            {filtradas.length} {filtradas.length === 1 ? 'pedido' : 'pedidos'}
          </span>
        </div>

        <div className="pedidos-tabla-scroll">
          <table className="pedidos-tabla">
            <thead>
              <tr>
                <th>Pedido</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Productos</th>
                <th>Total</th>
                <th>Pago</th>
                <th>Envío</th>
              </tr>
            </thead>
            <tbody>
              {filtradas.length === 0 ? (
                <tr>
                  <td colSpan="7" className="pedidos-vacio">
                    {ordenes.length === 0 ? 'Todavía no hay pedidos.' : 'Ningún pedido coincide con la búsqueda.'}
                  </td>
                </tr>
              ) : (
                filtradas.map((orden) => {
                  const pago = pagos[orden.idOrden];
                  const envio = envios[orden.idOrden];
                  return (
                    <tr key={orden.idOrden}>
                      <td className="pedidos-id">#{orden.idOrden}</td>
                      <td>{orden.fecha ? new Date(orden.fecha).toLocaleDateString('es-AR') : '-'}</td>
                      <td>{orden.nombreCliente || '-'}</td>
                      <td>
                        {(orden.detalles || []).map((d) => (
                          <div key={d.idDetalle}>{d.cantidad} × {d.nombreProducto}{d.tamano > 1 ? ` (${etiquetaMedida(d.tamano, d.unidadMedida)})` : ''}</div>
                        ))}
                      </td>
                      <td className="pedidos-total">{formatearPrecio(total(orden))}</td>
                      <td>
                        {pago ? (
                          <>
                            <span className={`estado-badge ${claseEstadoPago(pago.estado)}`}>
                              {textoEstadoPago(pago.estado)}
                            </span>
                            <div className="pedidos-detalle-chico">{pago.nombreMetodoPago}</div>
                            {!pago.estado && (
                              <button className="pedidos-btn" onClick={() => confirmarPago(pago)}>
                                Confirmar pago
                              </button>
                            )}
                          </>
                        ) : '-'}
                      </td>
                      <td>
                        {envio ? (
                          <>
                            <select
                              className={`pedidos-select estado-badge ${claseEstadoEnvio(envio.estado)}`}
                              value={envio.estado}
                              onChange={(e) => cambiarEstadoEnvio(envio, e.target.value)}
                              disabled={(envio.estado || '').toLowerCase() === 'cancelado'}
                              title={(envio.estado || '').toLowerCase() === 'cancelado' ? 'Un pedido cancelado no se puede reactivar' : undefined}
                            >
                              {/* Si el estado actual no está en la lista, se conserva como opción */}
                              {!ESTADOS_ENVIO.includes(envio.estado) && (
                                <option value={envio.estado}>{envio.estado}</option>
                              )}
                              {ESTADOS_ENVIO.map((e) => (
                                <option key={e} value={e}>{e}</option>
                              ))}
                            </select>
                            <div className="pedidos-detalle-chico">{envio.nombreEmpresa}</div>
                          </>
                        ) : '-'}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
